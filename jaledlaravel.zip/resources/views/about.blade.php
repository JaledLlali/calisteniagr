@extends('layouts.plantilla')

@section('title', 'About')

@section('content')

    <h1>Nosotros</h1>

@endsection
