@extends('layouts.plantilla')
@extends('layouts.editform')
@section('title', 'Cursos Edit')

@section('content')
    <h1>Página para editar cursos</h1>
    @section('form')
@endsection

