@extends('layouts.plantilla')
@extends('layouts.createform')
@section('title', 'Cursos Create')

@section('content')
    <h1>Página para crear cursos</h1>
    @section('form')
@endsection

