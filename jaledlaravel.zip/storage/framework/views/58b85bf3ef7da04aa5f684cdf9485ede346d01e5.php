<?php $__env->startSection('title', 'Cursos Create'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Página para crear cursos</h1>
    <?php $__env->startSection('form'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.createform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jaledlaravel\resources\views/cursos/create.blade.php ENDPATH**/ ?>