<div class="bg-<?php echo e($color); ?>-100 border-l-4 border-<?php echo e($color); ?>-500 text-<?php echo e($color); ?>-700 p-4" role="alert">
        <p class="font-bold">Be Warned</p>
        <p>Something not ideal might be happening.</p>
</div>
<?php /**PATH C:\laragon\www\jaledlaravel\resources\views/components/alert.blade.php ENDPATH**/ ?>