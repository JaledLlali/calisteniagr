<?php echo $__env->yieldContent('form'); ?>
<form action="<?php echo e(route('cursos.store')); ?>" method="POST">

    <?php echo csrf_field(); ?>

    <label>
        Nombre:
        <br>
        <input type="text" name="name" value="<?php echo e(old('name', $curso->name)); ?>">
    </label>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <br>
    <small>*<?php echo e($message); ?></small>
    <br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <label>
        <br>
        Descripcion:
        <br>
        <textarea name="description" rows="5" ><?php echo e(old('description', $curso->description)); ?></textarea>
    </label>

    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <br>
    <small>*<?php echo e($message); ?></small>
    <br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label>
        <br>
        Categoría:
        <br>
        <input type="text" name="category" value="<?php echo e(old('category', $curso->category)); ?>">
    </label>

    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <br>
    <small>*<?php echo e($message); ?></small>
    <br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <br>
    <button type="submit">Enviar curso</button>
</form>
<?php /**PATH C:\laragon\www\jaledlaravel\resources\views/layouts/editform.blade.php ENDPATH**/ ?>