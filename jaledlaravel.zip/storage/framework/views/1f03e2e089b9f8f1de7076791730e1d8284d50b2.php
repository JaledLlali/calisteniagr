<header>
    <nav>
        <ul>
            <li><a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Home</a>
            </li>
            <li><a href="<?php echo e(route('cursos.index')); ?>" class="<?php echo e(request()->routeIs('cursos.*') ? 'active' : ''); ?>">Cursos</a>
            </li>
            <li><a href="<?php echo e(route('about')); ?>" class="<?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">Nosotros</a>
            </li>
            <a href="<?php echo e(url('locale/en')); ?>" >Ingles</a>
            <a href="<?php echo e(url('locale/es')); ?>" >Español</a>
        </ul>
    </nav>

</header>
<?php /**PATH C:\laragon\www\jaledlaravel\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>