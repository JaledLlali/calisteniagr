<?php $__env->startSection('title', 'Cursos ' . $curso->name); ?>

<?php $__env->startSection('content'); ?>
    <h1>Bienvenido al curso <?php echo e($curso->name); ?></h1>
    <a href="<?php echo e(route('cursos.index')); ?>">Volver a todos los cursos</a>
    <br>
    <a href="<?php echo e(route('cursos.edit', $curso)); ?>">Editar curso</a>
    <p><strong>Categoría:</strong><?php echo e($curso->category); ?></p>
    <p><?php echo e($curso->description); ?></p>

    <form action="<?php echo e(route('cursos.destroy', $curso)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button type="submit">Eliminar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jaledlaravel\resources\views/cursos/show.blade.php ENDPATH**/ ?>