<?php $__env->startSection('title', "Jaled's Contact"); ?>
<?php $__env->startSection('content'); ?>
    <h1>Contenido yield Contact</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jaledlaravel\resources\views/contact.blade.php ENDPATH**/ ?>