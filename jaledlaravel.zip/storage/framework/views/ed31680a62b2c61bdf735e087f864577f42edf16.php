<?php $__env->startSection('title', 'Cursos Edit'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Página para editar cursos</h1>
    <?php $__env->startSection('form'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.editform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jaledlaravel\resources\views/cursos/edit.blade.php ENDPATH**/ ?>