<?php
 ?><?php /**PATH C:\laragon\www\jaledlaravel\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>