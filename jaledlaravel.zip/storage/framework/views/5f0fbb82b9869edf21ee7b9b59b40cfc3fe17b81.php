<?php $__env->startSection('title', "Jaled's Portfolio"); ?>

<?php $__env->startSection('content'); ?>
    <h1>Contenido yield Portfolio</h1>

    <ul>

        <?php $__empty_1 = true; $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolioItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li><?php echo e($portfolioItem['title']); ?> <small><?php echo e($loop->first ? 'Es el último elemento' : ''); ?></small>  </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li>No hay nada que mostrar</li>
        <?php endif; ?>

    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jaledlaravel\resources\views/portfolio.blade.php ENDPATH**/ ?>